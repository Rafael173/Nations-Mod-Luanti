Esse é o Mod Nations para Luanti, até a sua data de lançamento não havia registro (pelo menos que eu saiba) de algum mod de nações.

Os mods disponíveis para Luanti são de factions ainda assim, um pouco incompletos já que usam área protect para simular territórios.

O mod Nations se torna único pois utiliza chunks para definir territórios e terrenos privados, além de vir com proteção global do mundo (evitar que jogadores façam destruição atoa em mapas temáticos como earth).

Levei um tempo para fazer o Mod, então se puderem entrar no Discord para apoiar eu agradeço:

https://discord.gg/jfwrGwmnky


canal do YouTube:

https://www.youtube.com/@Rafael-Oliveira18k


Em resumo façam bom uso do Mod, só não retirem os créditos, isso seria injusto com quem passou meses programando e resolvendo erros do código.